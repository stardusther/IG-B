# Práctica 3. Menu

Q → salir

### Modos de dibujo disponibles

1 → Puntos
2 → Líneas (aristas)
3 → Sólido
4 → Sólido colores random

### Objetos disponibles
C → Cubo
E → Esfera
L → Clilindro
N → Cono
O → Objeto PLY (bethooven)
P → Pirámide
R → Objeto rotación (peón)
**S → Nintendo Switch**
X → Objeto extrusión

### Animaciones disponibles

_Para esta sección se necesitará combinar la tecla Fn con las siguientes:_

F1 → Rotar izq.
F2 → Rotar dcha.

