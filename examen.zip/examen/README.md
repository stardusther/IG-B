# Práctica 3. Menu

Q → salir

### Modos de dibujo disponibles

1 → Puntos
2 → Líneas (aristas)
3 → Sólido
4 → Sólido colores random

### Objetos disponibles
S → Ej1
A → Ej2

### Animaciones disponibles

_Para esta sección se necesitará combinar la tecla Fn con las siguientes:_

F1 → Rotar izq.
F2 → Rotar dcha.

